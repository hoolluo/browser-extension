/* ============================================================
   TabHarvest — 页面区域选择器（由 popup 通过 chrome.scripting 注入）
   流程：悬停高亮 -> 点击元素 -> 立即写入 chrome.storage.local
   并请求 background 重新打开 popup（由 popup 显示预览并确认提取）
   ============================================================ */
(() => {
  'use strict';

  // 若已有实例，先静默取消
  if (typeof window.__TABHARVEST_PICKER_CANCEL__ === 'function') {
    try { window.__TABHARVEST_PICKER_CANCEL__(); } catch (e) { /* ignore */ }
  }

  let mode = 'pick';          // 'pick' 当前页提取 | 'remember' 记住选择器
  let selectedEl = null;
  let hoverEl = null;
  let destroyed = false;
  let toastTimer = null;

  // ---------- 注入样式 ----------
  const oldStyle = document.getElementById('thp-style');
  if (oldStyle) oldStyle.remove();

  const styleEl = document.createElement('style');
  styleEl.id = 'thp-style';
  styleEl.textContent = [
    '.thp-box{position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #1877F2;',
    'background:rgba(24,119,242,.10);border-radius:4px;box-sizing:border-box;display:none;}',
    '.thp-tag{position:fixed;z-index:2147483647;pointer-events:none;background:#1877F2;color:#fff;',
    'font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:11px;',
    'font-weight:600;line-height:1.4;padding:2px 8px;border-radius:6px;',
    'box-shadow:0 2px 6px rgba(0,0,0,.25);max-width:320px;white-space:nowrap;overflow:hidden;',
    'text-overflow:ellipsis;display:none;}'
  ].join('');
  document.documentElement.appendChild(styleEl);

  // ---------- 高亮框 & 选择器标签 ----------
  const box = document.createElement('div');
  box.className = 'thp-box';
  const tag = document.createElement('div');
  tag.className = 'thp-tag';
  document.documentElement.append(box, tag);

  // ---------- 工具函数 ----------
  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
    return String(value).replace(/([^\w-])/g, '\\$1');
  }

  // 生成尽量简短且可靠的 CSS 选择器
  function selectorOf(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return `#${cssEscape(el.id)}`;

    const parts = [];
    let node = el;
    let depth = 0;

    while (node && node.nodeType === 1 && depth < 6) {
      const name = node.localName;
      if (!name || name === 'html' || name === 'body') break;

      let part = name;
      const parent = node.parentElement;
      if (parent) {
        const sameTag = Array.from(parent.children).filter((c) => c.localName === name);
        if (sameTag.length > 1) part += `:nth-of-type(${sameTag.indexOf(node) + 1})`;
      }
      parts.unshift(part);

      if (node.id) {
        parts.unshift(`#${cssEscape(node.id)}`);
        break;
      }
      node = parent;
      depth += 1;
    }

    return parts.join(' > ');
  }

  function isOurs(el) {
    return !!(el && el.closest && el.closest('.thp-box,.thp-tag,.thp-toast'));
  }

  function place(el) {
    if (!el || !el.isConnected) {
      box.style.display = 'none';
      tag.style.display = 'none';
      return;
    }
    const r = el.getBoundingClientRect();
    if (r.width === 0 && r.height === 0) {
      box.style.display = 'none';
      tag.style.display = 'none';
      return;
    }

    box.style.display = 'block';
    box.style.left = `${r.left}px`;
    box.style.top = `${r.top}px`;
    box.style.width = `${r.width}px`;
    box.style.height = `${r.height}px`;

    const label = selectorOf(el);
    tag.textContent = label.length > 48 ? `${label.slice(0, 47)}…` : label;
    tag.style.display = 'block';
    tag.style.left = `${Math.max(2, Math.min(r.left, window.innerWidth - 180))}px`;
    tag.style.top = `${r.top > 26 ? r.top - 24 : r.top + 2}px`;
  }

  // ---------- Toast ----------
  function toast(message, duration = 2000) {
    let t = document.getElementById('thp-toast');
    if (t) t.remove();

    t = document.createElement('div');
    t.id = 'thp-toast';
    t.className = 'thp-toast';
    t.textContent = message;
    t.style.cssText = [
      'position:fixed', 'left:50%', 'bottom:24px', 'transform:translateX(-50%)',
      'background:#111827', 'color:#fff',
      'font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif',
      'font-size:12px', 'padding:9px 16px', 'border-radius:20px', 'z-index:2147483647',
      'box-shadow:0 8px 24px rgba(0,0,0,.25)', 'opacity:1', 'transition:opacity .25s',
      'pointer-events:none'
    ].join(';');
    document.documentElement.appendChild(t);

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      t.style.opacity = '0';
      setTimeout(() => t.remove(), 260);
    }, duration);
  }

  // ---------- 事件处理 ----------
  function onMove(e) {
    if (selectedEl) return;
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || isOurs(el)) {
      hoverEl = null;
      box.style.display = 'none';
      tag.style.display = 'none';
      return;
    }
    hoverEl = el;
    place(el);
  }

  function blockEvent(e) {
    e.preventDefault();
    e.stopPropagation();
  }

  function onClick(e) {
    e.preventDefault();
    e.stopPropagation();

    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || isOurs(el)) return;

    selectedEl = el;
    place(el);
    finishSelection(el);
  }

  function onScroll() {
    place(selectedEl || hoverEl);
  }

  function onKey(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      cleanup(true);
    }
  }

  // ---------- 选中完成：写入存储并请求重新打开插件 ----------
  function finishSelection(el) {
    const text = (el.innerText || el.textContent || '')
      .replace(/\r\n?/g, '\n')
      .replace(/[ \t\u00a0]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    if (!text) {
      selectedEl = null;
      toast('该元素没有可提取的文本，请选择其他区域');
      return;
    }

    const payload = {
      mode,
      selector: selectorOf(el),
      text,
      title: document.title,
      url: location.href,
      timestamp: Date.now(),
    };

    const finish = () => {
      cleanup(false);
      try { chrome.storage.local.remove('tabharvestPickerMode'); } catch (e) { /* ignore */ }
      try {
        chrome.runtime.sendMessage({ type: 'tabharvest:open-popup' }, (res) => {
          // 读取最后错误以避免 "Unchecked runtime.lastError"
          void chrome.runtime.lastError;
          if (res && res.ok) {
            toast('已选中区域，正在打开插件…', 1500);
          } else {
            toast('已选中区域，请点击插件图标确认', 2600);
          }
        });
      } catch (e) {
        toast('已选中区域，请点击插件图标确认', 2600);
      }
    };

    try {
      chrome.storage.local.set({ tabharvestPicked: payload }, finish);
    } catch (e) {
      finish();
    }
  }

  // ---------- 清理 ----------
  function cleanup(wasCancel) {
    if (destroyed) return;
    destroyed = true;

    document.removeEventListener('mousemove', onMove, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('mousedown', blockEvent, true);
    document.removeEventListener('pointerdown', blockEvent, true);
    window.removeEventListener('keydown', onKey, true);
    window.removeEventListener('scroll', onScroll, true);
    window.removeEventListener('resize', onScroll, true);

    box.remove();
    tag.remove();
    styleEl.remove();
    window.__TABHARVEST_PICKER_CANCEL__ = null;

    if (wasCancel) {
      try { chrome.storage.local.remove('tabharvestPickerMode'); } catch (e) { /* ignore */ }
      toast('已取消选择', 1500);
    }
  }

  // ---------- 启动 ----------
  function start() {
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('click', onClick, true);
    document.addEventListener('mousedown', blockEvent, true);
    document.addEventListener('pointerdown', blockEvent, true);
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', onScroll, true);

    window.__TABHARVEST_PICKER_CANCEL__ = () => cleanup(false);
    toast('点击页面中要提取的元素，按 ESC 取消', 2800);
  }

  try {
    chrome.storage.local.get('tabharvestPickerMode', (data) => {
      if (destroyed) return;
      mode = (data && data.tabharvestPickerMode) || 'pick';
      start();
    });
  } catch (e) {
    mode = 'pick';
    start();
  }
})();
